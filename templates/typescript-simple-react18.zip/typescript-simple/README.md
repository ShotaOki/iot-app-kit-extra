# Standard Sample Project

# install

サンプルが使うリソース（MMD のファイルなど）を public ディレクトリにダウンロードする

```bash
npm run download
```

インストールする

```bash
npm install --legacy-peer-deps
```

アプリを開始する

```bash
npm run start
```
